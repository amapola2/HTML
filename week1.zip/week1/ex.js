function fn_over(obj) {
    console.log('콘솔에 프린트됨')
    console.log(obj)
    obj.src='media/꽃 1.jpeg';
   }
   function fn_out(obj) {
    obj.src='media/꽃 2.jpeg';
   }